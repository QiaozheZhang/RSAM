import time
import torch
import tqdm
import copy
import pdb

from utils.eval_utils import accuracy
from utils.utils import get_regularization_loss
from utils.logging import AverageMeter

from torch import optim
import torch.nn.functional as F

def train(train_loader, model, criterion, optimizer, args):
    losses = AverageMeter("Loss", ":.3f")
    top1 = AverageMeter("Acc@1", ":6.2f")
    top5 = AverageMeter("Acc@5", ":6.2f")
    top10 = AverageMeter("Acc@10", ":6.2f")
    
    # switch to train mode
    model.train()

    for i, (images, target) in tqdm.tqdm(
        enumerate(train_loader), ascii=True, total=len(train_loader)
    ):

        if args.gpu is not None:
            images = images.cuda(args.gpu, non_blocking=True)
            target = target.cuda(args.gpu, non_blocking=True)

        if args.arch == 'alexnet':
            images = F.interpolate(images, scale_factor=7)

        output = model(images)
        
        loss = criterion(output, target)
        
        regularization_loss = torch.tensor(0).to(f'cuda:{args.gpu}')
        
        #if args.regularization:
        regularization_loss =\
            get_regularization_loss(args, model, regularizer=args.regularization,
                                        lmbda=args.lmbda)
        
        #print('regularization_loss: ', regularization_loss)
        loss += regularization_loss
        
        acc1, acc5, acc10 = accuracy(output, target, topk=(1, 5, 10))
        losses.update(loss.item(), images.size(0))
        top1.update(acc1.item(), images.size(0))
        top5.update(acc5.item(), images.size(0))
        top10.update(acc10.item(), images.size(0))


        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
    return top1.avg, top5.avg, top10.avg, loss.item()

def validate(val_loader, model, criterion, args):
    losses = AverageMeter("Loss", ":.3f", write_val=False)
    top1 = AverageMeter("Acc@1", ":6.2f", write_val=False)
    top5 = AverageMeter("Acc@5", ":6.2f", write_val=False)
    top10 = AverageMeter("Acc@10", ":6.2f", write_val=False)
    
    model.eval()

    with torch.no_grad():
        for i, (images, target) in tqdm.tqdm(
            enumerate(val_loader), ascii=True, total=len(val_loader)
        ):
            if args.gpu is not None:
                images = images.cuda(args.gpu, non_blocking=True)
                target = target.cuda(args.gpu, non_blocking=True)

            if args.arch == 'alexnet':
                images = F.interpolate(images, scale_factor=7)

            output = model(images)

            loss = criterion(output, target)

            acc1, acc5, acc10 = accuracy(output, target, topk=(1, 5, 10))
            losses.update(loss.item(), images.size(0))
            top1.update(acc1.item(), images.size(0))
            top5.update(acc5.item(), images.size(0))
            top10.update(acc10.item(), images.size(0))

    print("Model top1 Accuracy: {}".format(top1.avg))
    return top1.avg, top5.avg, top10.avg, losses.avg