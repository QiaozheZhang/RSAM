from data.cifar10 import CIFAR10
from data.cifar100 import CIFAR100
from data.tinyimagenet import TinyImageNet

__ALL__ = [
    'CIFAR10',
    'CIFAR100',
    'TinyImageNet'
]