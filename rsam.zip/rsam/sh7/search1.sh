cd ../

trap "echo 'Stopping script...'; kill 0; exit" SIGINT SIGTERM

launch_commands_with_gpus() {
    local -n _commands=$1   
    local -n _gpus=$2     
    local max_concurrent=$3

    local total=${#_commands[@]}
    local idx=0

    while [ $idx -lt $total ]; do
        for ((j=0; j<$max_concurrent && idx<$total; j++, idx++)); do
            gpu_id=${_gpus[$((idx % ${#_gpus[@]}))]}
            cmd=${_commands[$idx]}
            cmd=${cmd//GPU_PLACEHOLDER/$gpu_id}
            echo "Launching: $cmd"
            eval "$cmd &"
        done
        wait
    done
}

echo "scripts $# will be run"

gpus=(0 1 3 4)

max_concurrent=4
commands=()

bias=True
lr_policy=cosine_lr
aug=True
augst=False
use_fix=False
warmup=5
mode=wd
optimizer=sgd
recipe=0
init=none

for alpha in 1.1; do
    for stre in 0.05 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1 1.1; do
        commands+=("python3 train_sam.py --arch TinyResNet50 --init none --dataset TinyImageNet --optimizer sgd --aug True --use_fix False --gpu GPU_PLACEHOLDER --epochs 100 --batch_size 128 --lr 0.2 --wd 0.0001 --lmbda 0 --renyi false --lr_policy cosine_lr --sam_mode NEWRSAM --renyi_s $stre --alpha $alpha")
    done
done

launch_commands_with_gpus commands gpus $max_concurrent
wait